$usuarios [] = ["nombre" => "Martín", "apellido" => "Torrent", "nombreUsuario" => "matorrent", "fecha" =>"1975-01-01", "mail" => "nanana@gmail.com", "password" => "nada","recordarme" => "on"];
