<?php

$usuarios = [];

$usuarios [] = ['nombre' => 'Cristhian', 'apellido' => 'Pabon','nombreUsuario' => 'cristhianpabon', 'fecha' =>'2018-09-14', 'mail' => 'cristhian@hotmail.com', 'password' => '123', 'recordarme' => 'on'];
$usuarios [] = ['nombre' => 'Juana', 'apellido' => 'Azurduy','nombreUsuario' => 'juanaazurduy', 'fecha' =>'2018-09-14', 'mail' => 'Juana@outlook.com', 'password' => '123', 'recordarme' => 'on'];
$usuarios [] = ['nombre' => 'Jannice', 'apellido' => 'Lopez','nombreUsuario' => 'JanniceLopez', 'fecha' =>'2018-09-14', 'mail' => 'Jannice@gmail.com', 'password' => '123'];
