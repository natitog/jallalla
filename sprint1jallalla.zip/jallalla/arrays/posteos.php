<?php

$posteos = [];

$posteos [] = ['image' => 'img/post/Cochabamba.jpg', 'title' => 'Cochabamba', 'description' => 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.'];
$posteos [] = ['image' => 'img/post/Copacabana.jpg', 'title' => 'Copacabana', 'description' => 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.'];
$posteos [] = ['image' => 'img/post/Lapaz.jpg', 'title' => 'La paz', 'description' => 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid.'];
