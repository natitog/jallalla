<?php

$preguntas = [];

$preguntas [] = ['pregunta' => 'Collapsible Group Item #1', 'respuestas' => '  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.'];
$preguntas [] = ['pregunta' => 'Collapsible Group Item #2', 'respuestas' => '  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.'];
$preguntas [] = ['pregunta' => 'Collapsible Group Item #3', 'respuestas' => '  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.'];
