<?php

class Usuario{


  

}

 ?>
